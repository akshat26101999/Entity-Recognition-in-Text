document.addEventListener("DOMContentLoaded", function () {
    const taggableText = document.getElementById("taggable-text");
    const selectedTextContainer = document.getElementById("selected-text");

    const labelMapping = {
        "PERSON": "Person",
        "ORG": "Organization",
        "GPE": "Geopolitical Entity",
        "LOC": "Location",
        "DATE": "Date",
        "TIME": "Time",
        "MONEY": "Money",
        "PERCENT": "Percent",
        // Add more labels as needed
    };

    function createDropdown() {
        const dropdown = document.createElement("select");
        dropdown.innerHTML = '<option value="">Select Tag</option>';
        for (const [key, value] of Object.entries(labelMapping)) {
            const option = document.createElement("option");
            option.value = key;
            option.textContent = value;
            dropdown.appendChild(option);
        }
        return dropdown;
    }

    function makeWordsClickable(textElement) {
        const text = textElement.textContent.trim();
        textElement.innerHTML = "";
        const words = text.split(/\s+/);

        words.forEach(word => {
            const span = document.createElement("span");
            span.textContent = word;
            span.classList.add("clickable-word");
            span.style.cursor = "pointer";
            span.addEventListener("click", function () {
                addWordToSelected(word, span);
            });
            textElement.appendChild(span);
            textElement.appendChild(document.createTextNode(" "));
        });
    }

    function addWordToSelected(word, wordElement) {
        const wordDiv = document.createElement("div");
        wordDiv.classList.add("selected-word");

        const wordSpan = document.createElement("span");
        wordSpan.textContent = word;
        wordDiv.appendChild(wordSpan);

        const dropdown = createDropdown();
        wordDiv.appendChild(document.createTextNode(" "));
        wordDiv.appendChild(dropdown);

        selectedTextContainer.appendChild(wordDiv);

        wordElement.style.pointerEvents = "none";
        wordElement.style.color = "grey";
    }

    function handleSubmit() {
        const selectedWords = document.querySelectorAll("#selected-text .selected-word");
        const userTags = {};
        selectedWords.forEach(wordDiv => {
            const word = wordDiv.firstChild.textContent;
            const tag = wordDiv.querySelector("select").value;
            userTags[word] = tag;
        });

        // Simulate backend verification
        const correctTags = {
            "Microsoft": "ORG",
            "Bill Gates": "PERSON",
            "Paul Allen": "PERSON",
            "Redmond": "GPE",
            "Washington": "GPE"
        };

        let feedbackMessage = "Results:<br>";
        for (const [word, tag] of Object.entries(userTags)) {
            if (correctTags[word] === tag) {
                feedbackMessage += `${word}: Correct (${labelMapping[tag]})<br>`;
            } else {
                feedbackMessage += `${word}: Incorrect (Expected ${labelMapping[correctTags[word]]}, Got ${labelMapping[tag] || "None"})<br>`;
            }
        }

        document.getElementById("feedback-message").innerHTML = feedbackMessage;
    }

    makeWordsClickable(taggableText);
    document.getElementById("submit-btn").addEventListener("click", handleSubmit);
});
